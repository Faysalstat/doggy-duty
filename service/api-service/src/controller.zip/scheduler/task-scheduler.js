const taskService = require("../service/task-service");
const communityService = require("../service/community-service");
const sendMail = require("../mail/mailer");
const { TASK_STATUS } = require("../model/enums");
const Community = require("../model/community");
const SchedulerLog = require("../model/scheduler-log");

exports.generateDailyTasks = async () => {
  let today = new Date();
  let smsLog = {};
  let mailLog = {};
  try {
    await taskService.generateDailyTasks({ scheduledDate: today });
    let param = {
      status: TASK_STATUS.PENDING,
    };
    const smsBody =
      "Doggy Duty, LLC\n\nNew Doggy Duty Work Order Created Today. Please visit www.DoggyDuty.Live to review and print your schedule.\n\nThank you!";
    const smsPayload = {
      messages: [
        {
          body: smsBody,
          to: "4074174915",
        },
        {
          body: smsBody,
          to: "8633995176",
        },
      ],
    };
    const { messages } = smsPayload;
    const smsResponse = await smsService.sendSms(messages);
    let response = await communityService.getAllJobOrderByDate(param, null);
    const emailBody = generateTaskListEmailBody(response);
    sendMail("doggydutypro@gmail.com", "Daily Tasks Generated", emailBody);
    sendMail("woof@doggyduty.pet", "Daily Tasks Generated", emailBody);
    sendMail("faysalstat04@gmail.com", "Daily Tasks Generated", emailBody);
  } catch (error) {
    let errorLog = await SchedulerLog.create({
      job_name: "Job Scheduler",
      job_type: "Job Generator",
      status: "FAILED",
      error_message: error.message
    })
  }
};

exports.generateInvoice = async () => {
  let today = new Date();
  try {
    let communities = await Community.findAll();
    for (let i = 0; i < communities.length; i++) {
      let community = communities[i].dataValues;
    }
  } catch (error) {}
};

const generateTaskListEmailBody = (tasks) => {
  let emailBody = `
      <h2>Daily Task List</h2>
      <p>Dear Team,</p>
      <p>Please find below the task list for today:</p>
      <table style="width: 100%; border-collapse: collapse;">
        <thead>
          <tr>
            <th style="border: 1px solid #ddd; padding: 8px;">Community Name</th>
            <th style="border: 1px solid #ddd; padding: 8px;">Address</th>
            <th style="border: 1px solid #ddd; padding: 8px;">Contact Person</th>
            <th style="border: 1px solid #ddd; padding: 8px;">Phone</th>
            <th style="border: 1px solid #ddd; padding: 8px;">Garbage Bin</th>
            <th style="border: 1px solid #ddd; padding: 8px;">Pet Station</th>
            <th style="border: 1px solid #ddd; padding: 8px;">Task Status</th>
          </tr>
        </thead>
        <tbody>
    `;

  tasks.forEach((task) => {
    emailBody += `
        <tr>
          <td style="border: 1px solid #ddd; padding: 8px;">${task.communityName}</td>
          <td style="border: 1px solid #ddd; padding: 8px;">${task.communityAddress}</td>
          <td style="border: 1px solid #ddd; padding: 8px;">${task.camOfcommunity}</td>
          <td style="border: 1px solid #ddd; padding: 8px;">${task.phone}</td>
          <td style="border: 1px solid #ddd; padding: 8px;">${task.noOfGarbageBin}</td>
          <td style="border: 1px solid #ddd; padding: 8px;">${task.noOfPetStation}</td>
          <td style="border: 1px solid #ddd; padding: 8px;">${task.taskStatus}</td>
        </tr>
      `;
  });

  emailBody += `
        </tbody>
      </table>
      <p>Thank you!</p>
      <p>Best regards,<br>Doggy Duty</p>
    `;

  return emailBody;
};
